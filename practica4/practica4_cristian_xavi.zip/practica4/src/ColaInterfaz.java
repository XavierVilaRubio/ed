public interface ColaInterfaz<T> {
    public boolean isEmpty();
    public void inserir(T x);
    public T treure();
}
