public abstract class Symbol {
}
