public class OpenParentesis extends Symbol{
}
