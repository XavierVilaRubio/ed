public class ClosingParentesis extends Symbol{
}
