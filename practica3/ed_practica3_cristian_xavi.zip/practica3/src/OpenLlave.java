public class OpenLlave extends Symbol{
}
